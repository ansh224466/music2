<h2 align="center">
    
[![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=WELCOME+TO+IRO+X+MUSIC)](https://github.com/shaeep043/Iro_X)

<h2 align="center">
    ──「 Iro X Music 」──
</h2>
<p align="center">
  <img src="https://te.legra.ph/file/7b9bfe8d7fbb2589071e3.jpg">
</p>

<p align="center">
<a href="https://github.com/shaeep043/Iro_x/stargazers"><img src="https://img.shields.io/github/stars/shaeep043/Iro_x?color=black&logo=github&logoColor=black&style=for-the-badge" alt="Stars" /></a>
<a href="https://github.com/shaeep043/Iro_x/network/members"> <img src="https://img.shields.io/github/forks/shaeep043/Iro_x?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
<a href="https://github.com/shaeep043/Iro_x/blob/master/LICENSE"> <img src="https://img.shields.io/badge/License-MIT-blueviolet?style=for-the-badge" alt="License" /> </a>
<a href="https://www.python.org/"> <img src="https://img.shields.io/badge/Written%20in-Python-orange?style=for-the-badge&logo=python" alt="Python" /> </a>
<a href="https://github.com/shaeep043/Iro_x/commits/shaeep043"> <img src="https://img.shields.io/github/last-commit/shaeep043/Iro_x?color=blue&logo=github&logoColor=green&style=for-the-badge" /></a>
</p>

<p align="center">
  <img src="https://te.legra.ph/file/b8e797457f437310813cb.jpg">
</p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/shaeep043/Iro_x"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʟᴏᴄᴀʟ ʜᴏsᴛ/ ᴠᴘs 」─
</h3>

- Get your [Necessary Variables](https://github.com/shaeep043/Iro_x/blob/master/sample.env)
- Upgrade and Update by :
`sudo apt-get update && sudo apt-get upgrade -y`
- Install Ffmpeg by :
`sudo apt-get install python3-pip ffmpeg -y`
- Install required packages by :
`sudo apt-get install python3-pip -y`
- Install pip by :
`sudo pip3 install -U pip`
- Install Node js by :
`curl -fssL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm`
- Clone the repository by :
`git clone https://github.com/shaeep043/Iro_x && cd Iro_x`
- Install requirements by :
`pip3 install -U -r requirements.txt`
- Fill your variables in the env by :
`vi sample.env`<br>
Press `I` on the keyboard for editing env<br>
Press `Ctrl+C` when you're done with editing env and `:wq` to save the env<br>
- Rename the env file by :
`mv sample.env .env`
- Install tmux to keep running your bot when you close the terminal by :
`sudo apt install tmux && tmux`
- Finally run the bot by :
`bash start`
- For getting out from tmux session : Press `Ctrl+b` and then `d`<br>
━━━━━━━━━━━━━━━━━━━━

<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://telegram.me/Iro_m_bot"><img src="https://img.shields.io/badge/MUSIC%20BOT-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<p align="center">
<a href="https://telegram.me/iro_x_support"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<p align="center">
<a href="https://telegram.me/iro_bot_support"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<h3 align="center">
    ─「 ᴄʀᴇᴅɪᴛs 」─
</h3>

<p align="center">
<a href="https://github.com/Iro09"> <img src="https://img.shields.io/badge/PIKACHU♡-black?style=for-the-badge&logo=github" alt="PIKACHU♡" /> </a>
<a href="https://github.com/pyrogram/pyrogram"> <img src="https://img.shields.io/badge/Pyrogram-black?style=for-the-badge&logo=github" alt="Pyrogram" /> </a>
<a href="https://github.com/FantasticSukhi"> <img src="https://img.shields.io/badge/BLACKMAMBA-black?style=for-the-badge&logo=github" alt="Blackmamba" /> </a>
<a href="https://github.com/raichuop07"> <img src="https://img.shields.io/badge/Raichu-black?style=for-the-badge&logo=github" alt="Raichu" /> </a>
</p>

- <b> _sᴩᴇᴄɪᴀʟ ᴛʜᴀɴᴋs ᴛᴏ [Black Mamba](https://github.com/FantasticSukhi) </b>
- <b> _sᴩᴇᴄɪᴀʟ ᴛʜᴀɴᴋs ᴛᴏ [Altron](https://t.me/TheAltron) </b>

